<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "dbsalario";
	
	//Criar a conexão com servidor
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>